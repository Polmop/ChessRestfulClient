int _darwin_get_dmem_info( PAPI_dmem_info_t * d );
int _darwin_get_memory_info( PAPI_hw_info_t * hwinfo, int cpu_type );
int _darwin_update_shlib_info( papi_mdi_t *mdi );

